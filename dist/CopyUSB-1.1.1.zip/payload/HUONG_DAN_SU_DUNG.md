# Hướng Dẫn Sử Dụng CopyUSB

## Giới thiệu
Chào mừng bạn đến với bộ công cụ **CopyUSB**. Đây là tập hợp script PowerShell giúp copy dữ liệu (đặc biệt thư viện MP3) từ thư mục nguồn sang nhiều USB cùng lúc, kiểm tra tính toàn vẹn, và tháo thiết bị an toàn. Bộ công cụ này phù hợp cho việc nhân bản nội dung hàng loạt mà vẫn kiểm soát được dung lượng, tốc độ và độ tin cậy. Nội dung dưới đây mô tả cách dùng thực tế trên Windows.

Nếu cần tài liệu test riêng, xem thêm `HUONG_DAN_TEST.md`.

> **Lưu ý trách nhiệm:** Script có thể xóa/format USB để chuẩn bị chép dữ liệu. Hãy kiểm tra kỹ tham số trước khi chạy và sao lưu dữ liệu quan trọng.

## Bắt đầu
### Yêu cầu hệ thống
- Windows 10/11 với PowerShell 5.1 trở lên (ưu tiên PowerShell 7+ nếu có).
- Quyền **Administrator** để thực hiện format, remount và thao tác thiết bị USB.
- Các tiện ích sẵn có trong Windows: `robocopy`, `diskpart`, cmdlet `Get-PnpDevice`/`Disable-PnpDevice` (để remount/reset driver).
- USB mục tiêu đủ dung lượng so với thư mục nguồn.

### Cài đặt
1. Tải mã nguồn từ kho lưu trữ về máy (zip hoặc `git clone`).
2. Giải nén và mở **Windows PowerShell** (nên chạy *Run as Administrator*).
3. Cho phép chạy script trong phiên hiện tại (không thay đổi hệ thống):
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   ```
4. Di chuyển tới thư mục chứa các file `*.ps1` của CopyUSB:
   ```powershell
   cd <đường-dẫn-thư-mục-CopyUSB>
   ```

### Tài khoản/Đăng nhập
CopyUSB không yêu cầu tài khoản hay đăng nhập. Chỉ cần phiên PowerShell có quyền Administrator.

## Tổng quan Giao diện
CopyUSB là công cụ dòng lệnh gồm các script chính:

- `master_copy_check_eject.ps1`: Quy trình tổng Copy → Check → Eject, chạy song song trên nhiều ổ; có thể bật thêm Remount khi cần.
- `check_copy_hash.ps1`: Kiểm tra nội dung thư mục nguồn/đích (tập trung file `.mp3`), hỗ trợ so sánh hash (MD5/SHA256).
- `Check-UsbDisk.ps1`: Kiểm tra và sửa lỗi filesystem trên thẻ nhớ/USB bằng `chkdsk`, hữu ích khi thẻ bị lỗi đọc/ghi hoặc cần check trước khi copy.
- `Remount-Usb.ps1`: Lưu cache thông tin USB và remount lại ký tự ổ khi bị rút/không còn mount.
- `removedrv.ps1`: Tháo/eject tất cả USB đã xử lý.
- `Reset-UsbStorage.ps1`: Làm mới driver USB Storage khi cần làm sạch trạng thái thiết bị.
- `Mp3FatSort.ps1`: Kiểm tra và sắp xếp lại thứ tự thư mục/file trên USB định dạng FAT để thiết bị nghe nhạc phát đúng thứ tự mong muốn.

Hiển thị log màu:
- **Xám**: thông tin chung.
- **Vàng**: cảnh báo (ví dụ ổ không phải USB, sắp format, remount...).
- **Đỏ**: lỗi.
- **Xanh lục**: thao tác thành công.


Tất cả script đều chạy từ PowerShell; `CopyUSB-GUI.ps1` cung cấp thêm giao diện
Windows. Thông số chính được in ra đầu phiên để bạn xác nhận mỗi khi chạy.

### Giao diện Windows và click phải vào folder

Mở GUI bằng lệnh:

```powershell
powershell -ExecutionPolicy Bypass -File .\CopyUSB-GUI.ps1
```

GUI có đầy đủ các tham số của script master, tự quét USB đang mount, mở một
console PowerShell riêng để theo dõi prompt/output, đồng thời đọc log theo thời
gian thực trong cửa sổ. Sau khi quy trình kết thúc, GUI vẫn chờ người dùng bấm
`Thoát`.

Nút `Eject USB` nằm cạnh `Quét USB`, dùng danh sách drive trong ô
`DestDrives (USB)` để tháo các USB đang chọn. Nút eject bị khóa khi flow đang
chạy và cửa sổ sẽ yêu cầu chờ nếu tiến trình eject chưa kết thúc.

Để thêm lệnh vào menu click phải của folder, chạy:

```powershell
powershell -ExecutionPolicy Bypass -File .\Register-CopyUSBContextMenu.ps1 -Action Install
```

Hoặc chạy `install_copyusb_context_menu.bat`. Khi click phải vào một folder và
chọn `CopyUSB: copy folder tới USB`, GUI sẽ mở với folder đó làm `SourceRoot`.
Đăng ký dùng `HKCU` nên không cần quyền Administrator; gỡ bằng
`uninstall_copyusb_context_menu.bat` hoặc `-Action Uninstall`.

GUI có các chế độ chạy độc lập:

- `CopyWorkflow`: copy tới USB và dùng các checkbox `check_copy_hash`,
  `Check-UsbDisk`, `Mp3FatSort` để bật/tắt từng bước.
- `SyncWorkflow`: đồng bộ incremental từ source sang đích, check hash chỉ các
  file `.mp3` có trong manifest vừa đồng bộ, sau đó chạy `CheckAndSort`. Mặc
  định `SyncMode=Mirror` dùng robocopy `/MIR` để xóa file/thư mục dư ở đích;
  chọn `UpdateOnly` nếu muốn giữ file dư. Trước khi sync, flow chọn các file
  cuối ở đích có tổng dung lượng tối thiểu bằng nhóm sync, đồng thời loại các
  file sẽ bị `Mirror` xóa; sau đó hash cả hai nhóm để phát hiện trường hợp thẻ
  nhớ bị ghi đè vòng.
  Khi kết thúc, console chờ Enter để xem log; dùng `-NoPause` nếu muốn tự động thoát.
- `CheckCopyHash`: chỉ chạy `check_copy_hash.ps1`.
- `CheckUsbDisk`: chỉ chạy `Check-UsbDisk.ps1`, có thể bật `Fix lỗi disk`.
- `Mp3FatSort`: chỉ chạy `Mp3FatSort.ps1`, chọn được mode, scope, filter và
  throttle.

Khi bật `Enable check_copy_hash`, trường `HashLastN` và `HashAlgorithm` được
  mở để thay đổi. `HashLastN = 0` nghĩa là hash toàn bộ file chung.

## Hướng dẫn Sử dụng Tính năng
### 1. Copy song song nhiều USB và kiểm tra tự động
**Mục đích:** Chuẩn bị USB (xóa/format khi cần), copy song song từ thư mục nguồn, kiểm tra hash tùy chọn, và eject an toàn.

**Thực hiện:**
1. Gắn các USB cần xử lý và ghi nhận ký tự ổ (ví dụ `F: G: H:`...).
2. Chạy lệnh:
   ```powershell
   .\master_copy_check_eject.ps1 -SourceRoot "D:\DuLieuNguon" -SkipEject
   ```
   - Sẽ tự động Copy + Check tới tất cả các ổ (8 ổ từ F: cho đến M:) 
   - Khi bỏ -SkipEject sẽ tự động eject Usb khi copy & check xong. 
   - Khi cần check file kỹ càng (dùng file hash) thêm -EnableHash & -HashLastN 100 (số file hash cuối list) 
    - Xác định ổ đích thêm -DestDrives (vd: -DestDrives F:,G:,H:) 
    ```powershell
   .\master_copy_check_eject.ps1 -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G:,H: -EnableHash -HashLastN 100
   ```
   - Mặc định `-RemountDrive 0`: bỏ qua bước `Capture thông tin remount` và không tự remount khi USB bị rớt/mất mount.
   - Chỉ khi cần mới bật `-RemountDrive 1` để cho phép capture cache remount và tự remount:
    ```powershell
   .\master_copy_check_eject.ps1 -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G: -RemountDrive 1
   ```
4. Xem lại cấu hình được in ra, gõ `Y` để tiếp tục (hoặc thêm `-AutoYes` để bỏ qua xác nhận - khi đó sẽ tự động xóa / format ổ).
5. Theo dõi log hiển thị; file log chi tiết được lưu trong thư mục `logs`.

**Mẹo/Lưu ý:**
- Script tự kiểm tra dung lượng, ưu tiên xóa file thừa hoặc quick format FAT32 nếu ổ đủ lớn; ổ >32GB có thể không format FAT32 được trên Windows.
- Có thể bật check filesystem trước khi copy bằng `-CheckDiskBeforeCopy`; thêm `-FixDiskErrors` để tự gọi `chkdsk /f /x` khi phát hiện lỗi.
- Mặc định script không remount. Khi bật `-RemountDrive 1`, script sẽ capture cache remount đầu phiên và thử remount (dựa trên `Remount-Usb.ps1`) nếu USB bị rút/mất mount trong lúc copy.
- Bỏ qua bước eject bằng `-SkipEject` nếu muốn giữ ổ gắn sau khi copy.
- Chỉ cần chạy PowerShell Admin nếu dùng các chức năng cần quyền cao như format, fix filesystem hoặc bật `-RemountDrive 1`.
- Dùng `-AutoYes` khi đã kiểm thử ổn định để chạy không cần canh prompt (khi đó sẽ tự động xóa / format ổ)
- Mặc định chỉ dùng 1 thread copy duy nhất, theo như kinh nghiệm thực tế khi thread copy > 1 sẽ gặp nhiều lỗi copy & nhanh hỏng thẻ.
- Với USB/thẻ nhớ removable dưới 64GB, có thể bật `-ForceFormatMemoryCard` để ép format trước khi copy; thiết bị trên 32GB sẽ dùng exFAT. Tùy chọn này xóa toàn bộ dữ liệu trên ổ, cần xác nhận nếu không dùng `-AutoYes`.
- Có thể chạy riêng flow đồng bộ bằng: `.master_copy_check_eject.ps1 -SyncWorkflow -SyncMode Mirror -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G:`. `Mirror` xóa file dư ở đích; `UpdateOnly` chỉ cập nhật file từ nguồn.
- Khi nhấn `Ctrl+C`, đóng console PowerShell hoặc đóng GUI, master/GUI sẽ cố gắng dừng toàn bộ process con đang chạy (đặc biệt robocopy) theo cây process.

Ví dụ bật check/fix thẻ nhớ trước khi copy:
```powershell
.\master_copy_check_eject.ps1 -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G: -CheckDiskBeforeCopy -FixDiskErrors
```

### 2. Kiểm tra và sửa lỗi thẻ nhớ/USB kiểu Check Disk
**Mục đích:** Quét filesystem của thẻ nhớ/USB, phát hiện lỗi kiểu Windows Check Disk và tùy chọn sửa lỗi trước khi copy.

**Thực hiện:**
```powershell
.\Check-UsbDisk.ps1 -DestDrives F:,G:
```

Khi muốn tự sửa lỗi:
```powershell
.\Check-UsbDisk.ps1 -DestDrives F: -Fix
```

**Mẹo/Lưu ý:**
- `-Fix` nên chạy bằng PowerShell `Run as Administrator`.
- Khi sửa lỗi, script dùng `chkdsk /f /x`, có thể dismount ổ tạm thời rồi mount lại.
- Mã thoát chính: `0` = sạch lỗi, `1` = đã sửa xong, `2` = có lỗi nhưng chưa sửa, `3` = sửa chưa xong.

### 3. Kiểm tra nội dung và hash thư viện MP3
**Mục đích:** Đối chiếu danh sách file `.mp3` giữa nguồn và nhiều ổ đích; tùy chọn so sánh hash toàn bộ hoặc N file cuối.

**Thực hiện:**
```powershell
.\check_copy_hash.ps1 -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G: -Hash -HashLastN 0 -HashAlgorithm MD5
```

**Mẹo/Lưu ý:**
- Bỏ tham số `-Hash` để chạy nhanh (so sánh tên/size). Dùng `-HashLastN <N>` để tăng tốc khi thư viện rất lớn.
- Thêm `-LogFile <path>` để gom log chung với bước copy của master script.

### 4. Lưu cache và remount USB khi bị rớt
**Mục đích:** Ghi lại thông tin ổ USB hiện tại (serial, dung lượng, partition) để gán lại đúng ký tự ổ nếu USB bị ngắt kết nối trong quá trình copy.

**Lưu ý quan trọng:** Trong `master_copy_check_eject.ps1`, tính năng này hiện mặc định tắt với `-RemountDrive 0`. Chỉ bật `-RemountDrive 1` khi bạn muốn master script tự capture cache remount và tự remount.

**Thực hiện:**
- Capture cache trước khi copy (chỉ cần khi dùng remount thủ công hoặc chạy master script với `-RemountDrive 1`):
  ```powershell
  .\Remount-Usb.ps1 -Mode Capture -Drive F:,G: -CachePath .\usb_remount_cache.json
  ```
- Khi cần remount thủ công:
  ```powershell
  .\Remount-Usb.ps1 -Mode Remount -Drive F: -CachePath .\usb_remount_cache.json -WaitSec 20
  ```

**Mẹo/Lưu ý:**
- Yêu cầu PowerShell chạy với quyền Administrator để thao tác driver/partition.
- Đảm bảo ký tự ổ không bị thiết bị khác chiếm trước khi remount.

Ví dụ master script có bật remount:
```powershell
.\master_copy_check_eject.ps1 -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G: -RemountDrive 1 -SkipEject
```

Ví dụ master script giữ mặc định không remount:
```powershell
.\master_copy_check_eject.ps1 -SourceRoot "D:\DuLieuNguon" -DestDrives F:,G: -RemountDrive 0 -SkipEject
```

### 5. Tháo/eject USB sau khi hoàn tất
**Mục đích:** Eject an toàn các ổ USB đã xử lý để tránh lỗi ghi.

**Thực hiện:**
```powershell
.\removedrv.ps1
```
hoặc 
```bat
removedrv.bat
```
**Mẹo/Lưu ý:**
- Trong master script, bước eject diễn ra tự động trừ khi bật `-SkipEject`.

### 6. Làm mới driver USB Storage (khi remount thất bại)
**Mục đích:** Đặt lại trạng thái driver USB trong trường hợp thiết bị không nhận hoặc gán sai ký tự ổ.

**Thực hiện:**
```powershell
.\Reset-UsbStorage.ps1
```

**Mẹo/Lưu ý:**
- Chạy với quyền Administrator; sau khi reset có thể cần rút cắm lại USB.

### 7. Sắp xếp lại thứ tự phát nhạc trên thiết bị MP3 (FAT)
**Mục đích:** Một số máy nghe MP3 đọc file theo thứ tự ghi trong bảng FAT thay vì tên file. `Mp3FatSort.ps1` giúp kiểm tra và sắp xếp lại thứ tự này để thiết bị phát đúng playlist mong muốn.

**Chuẩn bị:**
- Cắm USB cần sắp xếp (định dạng FAT32/exFAT).
- Bảo đảm thư mục `tools\yafs\` đi kèm nằm cùng thư mục script. Lần đầu có thể cài YAFS ra đường dẫn cố định:
  ```powershell
  .\Mp3FatSort.ps1 -InstallYafs -YafsPath "C:\\Tools\\yafs\\yafs.exe"
  ```

**Thực hiện:**
1. Kiểm tra thứ tự hiện tại (không ghi thay đổi):
   ```powershell
   .\Mp3FatSort.ps1 -Device 'F:' -Mode CheckOnly
   ```
   Tệp `tree.xml` sẽ được lưu trong thư mục hiện tại để bạn xem thứ tự.
2. Sắp xếp tự động theo tên thư mục/file (ưu tiên thư mục trước file):
   ```powershell
   .\Mp3FatSort.ps1 -Device 'F:' -Mode CheckAndSort -SortScope Both -FileFilter MediaOnly -Force
   ```
   Tham số `-Force` để chạy song song nhiều ổ cùng lúc & bỏ qua bước confirm (hỏi lại) trước khi ghi.
3. Áp dụng cho nhiều USB giống nhau:
   ```powershell
   .\Mp3FatSort.ps1 -Device 'F:,G:,H:' -Mode CheckAndSort -ThrottleLimit 2
   ```

**Mẹo/Lưu ý:**
- Nếu thiết bị không phát đúng thứ tự list sau khi sắp xếp, ko cần xóa đi copy lại mà chỉ cần chạy `Mp3FatSort.ps1` trước khi eject.
- Khi chạy `Mp3FatSort.ps1` nếu gặp lỗi “Access is denied” hãy đóng File Explorer/ứng dụng đang mở file trên USB để cho phép sửa thứ tự file (hoặc chạy PowerShell với quyền Administrator).
- Có thể dùng `-SortScope FilesOnly` nếu chỉ muốn đổi thứ tự file trong cùng thư mục, giữ nguyên thứ tự thư mục chính.

### 8. Test mô phỏng cờ RemountDrive
**Mục đích:** Kiểm tra nhanh việc script chính đã bật/tắt đúng các nhánh `capture remount`, `cảnh báo admin cho remount`, và `auto-remount` mà không cần cắm USB thật.

**Thực hiện:**
```powershell
pwsh .\Test\Test-RemountDriveFlag.ps1
```

**Kết quả mong đợi:**
- `RemountDrive=0` => `Capture=Skipped`, `AdminWarning=Skipped`, `AutoRemountBeforeCopy=Skipped`, `AutoRemountAfterFailure=Skipped`.
- `RemountDrive=1` => `Capture=Enabled`, `AdminWarning=Conditional`, `AutoRemountBeforeCopy=Enabled`, `AutoRemountAfterFailure=Enabled`.

## Xử lý sự cố (Troubleshooting)
- **Không tìm thấy USB hợp lệ / báo Size=0:** Kiểm tra USB đã được nhận dạng trong Windows và có dung lượng thật; thử cắm lại. Chỉ cần `Remount-Usb.ps1 -Mode Capture` nếu bạn thực sự định dùng remount.
- **Thiếu dung lượng trống:** Master script sẽ bỏ qua ổ không đủ dung lượng. Giảm thư mục nguồn hoặc đổi USB dung lượng lớn hơn.
- **Không format được FAT32 (>32GB):** Dùng USB nhỏ hơn hoặc format thủ công sang exFAT rồi chạy lại với tùy chọn mirror (`/MIR`) khi cần xóa file thừa.
- **Bị chặn bởi ExecutionPolicy:** Đã xử lý bằng `Set-ExecutionPolicy -Scope Process Bypass`. Nếu vẫn lỗi, mở PowerShell bằng quyền Administrator và thử lại.
- **Remount thất bại:** Xác nhận bạn đang chạy với `-RemountDrive 1` hoặc remount thủ công bằng `Remount-Usb.ps1`. Đảm bảo đã capture cache trước đó; thử `Reset-UsbStorage.ps1` rồi remount lại. (phần này có thể ko có tác dụng vì chưa được test đầy đủ)

## Câu hỏi thường gặp (FAQ)
- **Có thể chỉ chạy bước kiểm tra không?** Có. Dùng `check_copy_hash.ps1` độc lập để kiểm tra thư mục đích hiện có.
- **Muốn giữ nguyên dữ liệu trên USB?** Thêm `-SkipCleanup` nếu chỉ muốn copy thêm; master script chỉ xóa/format khi cần giải phóng dung lượng.
- **Có bắt buộc chạy PowerShell 7?** Không, nhưng PowerShell 7+ giúp hiệu năng tốt hơn; script tự phát hiện và ưu tiên nếu có.
- **Log lưu ở đâu?** Theo mặc định master script tạo file trong thư mục `logs` (ví dụ `copycheckeject_yyyyMMdd_HHmmss.log`). Bạn có thể chỉ định `-LogDir` riêng.
- **Có bắt buộc hash?** Không. Không bật `-Hash` thì check chỉ so sánh tên/kích thước nên chạy nhanh hơn.
- **Có bắt buộc dùng remount?** Không. Mặc định `master_copy_check_eject.ps1` chạy với `-RemountDrive 0`, tức là không capture cache remount và không tự remount.
- **Có thể dừng giữa chừng?** Có. Nhấn `Ctrl+C`; lần chạy sau script sẽ đánh giá lại ổ và copy tiếp nếu cần.
- **Có hỗ trợ định dạng ngoài mp3?** Logic kiểm tra chỉ nhắm file `.mp3`. Nội dung khác vẫn được copy nhưng không được thống kê/hashing.

## Thông tin Liên hệ & Hỗ trợ
- Email hỗ trợ: `quan.nguyenduc@gmail.com`
- Điện thoại: `+84-000-000-000`
- Trang chủ/Repo: Vui lòng xem kho chứa CopyUSB nơi bạn tải script.
- Ref: [https://wordpress.com/quannd](https://quannd.wordpress.com/)
- Nếu cần trợ giúp nhanh: chạy script với tham số `-Help` (hoặc `-h`) để xem hướng dẫn tích hợp.
